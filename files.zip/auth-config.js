/**
 * ============================================================
 *  LINE WORKS OAuth 2.0 설정
 * ============================================================
 *  
 *  [설정 방법]
 *  1. LINE WORKS Admin  →  Developer Console 접속
 *     https://developers.worksmobile.com/
 *  
 *  2. "API 2.0" 앱 등록 (또는 기존 앱 사용)
 *     - 앱 이름: 중앙알텍 포털
 *     - Redirect URI: 아래 REDIRECT_URI 값과 동일하게 등록
 *     - Scope: user.read (사용자 정보 읽기)
 *  
 *  3. 발급받은 Client ID / Client Secret 을 아래에 입력
 * ============================================================
 */
const AUTH_CONFIG = {
  // ── LINE WORKS Developer Console 에서 발급 ──
  CLIENT_ID:     'YOUR_CLIENT_ID_HERE',
  CLIENT_SECRET: 'YOUR_CLIENT_SECRET_HERE',

  // ── 콜백 주소 (Developer Console 의 Redirect URI 와 동일해야 함) ──
  // NAS 주소에 맞게 수정하세요
  REDIRECT_URI:  'https://your-nas-domain.com/callback.html',

  // ── LINE WORKS OAuth 엔드포인트 ──
  AUTH_URL:      'https://auth.worksmobile.com/oauth2/v2.0/authorize',
  TOKEN_URL:     'https://auth.worksmobile.com/oauth2/v2.0/token',
  PROFILE_URL:   'https://www.worksapis.com/v1.0/users/me',

  // ── 요청 권한 ──
  SCOPE:         'user.read',

  // ── 세션 유지 시간 (밀리초, 기본 8시간) ──
  SESSION_TTL:   8 * 60 * 60 * 1000,

  // ── 로그인 후 이동할 메인 페이지 ──
  MAIN_PAGE:     'portal.html',
};
