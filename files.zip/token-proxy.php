<?php
/**
 * ============================================================
 *  token-proxy.php — LINE WORKS 토큰 교환 서버 프록시
 * ============================================================
 *  Client Secret 을 브라우저에 노출하지 않기 위한 서버측 프록시.
 *  Synology NAS Web Station 에서 PHP 가 활성화되어 있으면 사용 가능.
 * ============================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

// ── 설정값 (auth-config.js 와 동일하게 유지) ──
$CLIENT_ID     = 'YOUR_CLIENT_ID_HERE';
$CLIENT_SECRET = 'YOUR_CLIENT_SECRET_HERE';
$REDIRECT_URI  = 'https://your-nas-domain.com/callback.html';
$TOKEN_URL     = 'https://auth.worksmobile.com/oauth2/v2.0/token';

// ── POST 만 허용 ──
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$code = $_POST['code'] ?? '';
if (empty($code)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing authorization code']);
    exit;
}

// ── LINE WORKS 토큰 엔드포인트 호출 ──
$postData = http_build_query([
    'grant_type'    => 'authorization_code',
    'client_id'     => $CLIENT_ID,
    'client_secret' => $CLIENT_SECRET,
    'code'          => $code,
    'redirect_uri'  => $REDIRECT_URI,
]);

$ch = curl_init($TOKEN_URL);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $postData,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error    = curl_error($ch);
curl_close($ch);

if ($error) {
    http_response_code(502);
    echo json_encode(['error' => 'Token request failed', 'detail' => $error]);
    exit;
}

http_response_code($httpCode);
echo $response;
